const  users = [
    {
        'username': 'user1',
        'password': 'test1',
    },
    {
        'username': 'user2',
        'password': 'test2',
    },
];
export default users;
